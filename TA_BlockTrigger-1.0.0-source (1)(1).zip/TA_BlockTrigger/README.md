# TA_BlockTrigger

**Author:** MamaD_TA
**Version:** 1.0.0
**Base:** Paper 1.20.1 (also runs on newer Paper versions)
**Java:** 17+

Assign a command to any block, then let players trigger it by clicking that block.

An administrator looks at a block and runs `/bt <console|player> <command> <right|left|both>`.
From that moment on, every player who clicks that exact block runs the stored command —
as the server console or as the clicking player, with full placeholder support.

Everything is configurable: permissions, worlds, click/execution behaviour, cooldowns,
sounds, messages, placeholders and storage. No code changes are ever required.

---

## 1. Features

* **Exact block binding** — the block you are looking at (ray-traced, configurable distance)
  receives the command. Multiple blocks can hold different commands, each identified by
  world UUID + X/Y/Z.
* **Two execution types** — `console` (run as the server) and `player` (run as the clicking player).
* **Three click modes** — `right`, `left` and `both`.
* **Flexible command parser** — the first argument is the execution type, the last argument is
  the click type, everything in between is kept verbatim (spaces included). Both edge
  arguments are optional and fall back to configurable defaults.
* **Built-in placeholders** — `{player}`, `{uuid}`, `{world}`, `{x}`, `{y}`, `{z}`, each one
  switchable.
* **Command removal** — `/bt remove` deletes the binding of the targeted block only.
* **OP-only by default** — `/bt` is restricted to operators; the permission model
  (OP only / permission node / both) is configurable. Clicking configured blocks works for
  **every** player, including non-OPs.
* **Left-click support done right** — off-hand duplicates, duplicate events in the same tick and
  accidental block breaking are all handled (and configurable).
* **Cooldowns** — per player or per block, optionally separate for left/right clicks.
* **Fully configurable messages** — `messages.yml` with colour codes, hex colours, a prefix and
  a per-message kill switch.
* **Fully configurable sounds** — 7 sound slots, each with enable/disable, sound name, volume and
  pitch; invalid sound names are reported and safely ignored.
* **Reliable storage** — `blocks.yml`, saved immediately on every change through an atomic
  write, coalesced on a single background thread. World UUIDs are stored so renamed/re-imported
  worlds keep working, and entries are rebound automatically when a world loads late.
* **Live reload** — `/bt reload` re-applies `config.yml`, `messages.yml` and the block data
  without a restart and without losing configured blocks.
* **Multi-version friendly** — only stable Bukkit/Paper API is used (no NMS, no version-specific
  code). Sounds are played through key-based Adventure sounds, which keeps working on newer
  Paper versions where `org.bukkit.Sound` is no longer an enum.
* **Lightweight** — O(1) block lookups, cached configuration, no per-tick work; only two
  low-frequency tasks (auto-save safety net and cooldown housekeeping).

---

## 2. Requirements

| Requirement | Value |
|---|---|
| Server | Paper 1.20.1 or newer (Spigot-like forks not tested) |
| Java | 17 or newer (21 recommended for 1.20.4+) |
| Build tool | Maven 3.6+ |

---

## 3. Building

```bash
cd TA_BlockTrigger
mvn -B clean package
```

The ready-to-use plugin is produced at:

```
target/TA_BlockTrigger-1.0.0.jar
```

A pre-built jar is also shipped next to this README as `TA_BlockTrigger-1.0.0.jar`.

To build for another Paper version, change the `paper.version` property in `pom.xml`
(e.g. `1.21.4-R0.1-SNAPSHOT`); the source uses no version-specific API, so it compiles
against newer APIs unchanged.

---

## 4. Installation

1. Stop the server.
2. Copy `TA_BlockTrigger-1.0.0.jar` into `plugins/`.
3. Start the server. The plugin generates:
   * `plugins/TA_BlockTrigger/config.yml`
   * `plugins/TA_BlockTrigger/messages.yml`
   * `plugins/TA_BlockTrigger/blocks.yml`
4. Optional: edit the configuration files and run `/bt reload`.

---

## 5. Quick start

```
1. Look directly at the block you want to use.
2. /bt console say Hello World right
3. Right-click that block → the console says "Hello World".
```

More examples:

| Command | Effect |
|---|---|
| `/bt console say Hello World right` | right click → console runs `say Hello World` |
| `/bt player spawn right` | right click → the player runs `/spawn` |
| `/bt console eco give {player} 100 both` | left **or** right click → console gives the clicking player 100 |
| `/bt console warp pvp left` | left click → console runs `warp pvp` |
| `/bt console summon lightning_bolt both` | both clicks → console summons lightning |
| `/bt remove` | removes the command from the targeted block |
| `/bt reload` | reloads configuration, messages and block data |

---

## 6. Command reference

```
/bt <console|player> <command ...> [right|left|both]
/bt <command ...> [right|left|both]      (uses settings.default-execution-type)
/bt remove
/bt reload
/bt help
```

Aliases: `ctb`, `tbt`, `blocktrigger`, `tablocktrigger`, `cmdtoblock` (the old `/ctb` command keeps working).

### How the arguments are parsed

* **First argument** — if it is exactly `console` or `player`, it is the execution type.
  Otherwise the whole argument list is treated as the command and the configured default
  execution type is used.
* **Last argument** — if it is exactly `right`, `left` or `both`, it is the click type.
  Otherwise the configured default click type is used.
* **Everything in between** is the command, joined with single spaces, exactly as typed —
  multiple arguments and spaces are preserved.
* A **leading `/`** is accepted when `execution.accept-leading-slash` is `true`
  (default) and is always stripped before execution.

Examples of valid input:

```
/bt console eco give {player} 100 both
/bt player /spawn right
/bt say turn left now right      -> command "say turn left now", click "right"
/bt say hello                    -> default execution + default click
```

### Tab completion

* first argument: `console`, `player`, `remove`, `reload`, `help`
* last argument while defining a command: `right`, `left`, `both`

---

## 7. Placeholders

| Placeholder | Replaced with | Toggle |
|---|---|---|
| `{player}` | name of the player who clicked the block | `placeholders.player` |
| `{uuid}` | UUID of that player | `placeholders.uuid` |
| `{world}` | name of the world the player is in | `placeholders.world` |
| `{x}` `{y}` `{z}` | the player's block coordinates | `placeholders.coordinates` |

Placeholders are applied only when **both** `placeholders.enabled` and
`execution.use-placeholders` are `true`.

The block's own coordinates are not placeholders, but they are shown in the confirmation
messages (`{world}`, `{x}`, `{y}`, `{z}` there refer to the block).

---

## 8. Permissions

| Node | Default | Purpose |
|---|---|---|
| `tablocktrigger.admin` | `op` | use `/bt` when the permission based mode is enabled |
| `tablocktrigger.use` | `true` | trigger block commands when `execution.require-permission: true` |

By default `/bt` is **OP-only** (`permissions.op-only: true`). The checks are evaluated in
this order (all configurable):

1. console / command blocks — always allowed;
2. `permissions.ops-bypass: true` and the sender is an OP — allowed;
3. `permissions.op-only: true` and the sender is an OP — allowed;
4. `permissions.use-permission-node: true` and the sender has `permissions.permission-node` — allowed;
5. both switches `false` — the sender still needs `permissions.permission-node`
   (so `/bt` can never become public by accident).

Non-OP players get a configurable permission-denied message and sound, cannot configure,
modify, remove or reload anything, but **can** click configured blocks.

---

## 9. Configuration

Three files in `plugins/TA_BlockTrigger/`:

| File | Purpose |
|---|---|
| `config.yml` | behaviour, permissions, worlds, interactions, execution, cooldowns, sounds, placeholders, storage |
| `messages.yml` | every message, with colour/hex codes, prefix and per-message kill switch |
| `blocks.yml` | the stored block commands (managed by the plugin) |

A detailed option-by-option reference lives in **[docs/CONFIGURATION.md](docs/CONFIGURATION.md)**.
Every option in those files is functional.

Minimal example:

```yaml
settings:
  enabled: true
  max-selection-distance: 10
  default-execution-type: console
  default-click-type: right
  debug: false

permissions:
  op-only: true
  use-permission-node: false
  permission-node: "tablocktrigger.admin"
  ops-bypass: true

interactions:
  right-click: true
  left-click: true
  both: true
  prevent-block-breaking: true

execution:
  console: true
  player: true
  accept-leading-slash: true
  use-placeholders: true

cooldown:
  enabled: false
  seconds: 1.0
  type: "player"
  separate-click-types: true
```

### Sounds

Accepted sound notations (all validated, invalid names are logged and ignored):

```yaml
sound: "ENTITY_EXPERIENCE_ORB_PICKUP"          # Bukkit constant
sound: "entity.experience_orb.pickup"          # Minecraft key
sound: "minecraft:block.note_block.bell"       # namespaced key
```

Sound slots: `set-command`, `remove-command`, `invalid-command`, `no-permission`, `click`,
`reload`, `cooldown` — each with `enabled`, `sound`, `volume` (0–10) and `pitch` (0.1–2).

### Messages

`messages.yml` supports `&a`-style colour codes, `&#RRGGBB` hex colours, the `{prefix}`
placeholder and a per-message kill switch: set the value to `''`, `-` or `disabled` to hide it.
Missing keys automatically fall back to the copy bundled inside the jar, so a partial or
outdated `messages.yml` can never break anything.

---

## 10. Data storage

`blocks.yml` (name configurable through `storage.file`):

```yaml
blocks:
  - world: world
    world-uuid: aafa890c-647e-4342-9ebd-8bb1441fa97d
    x: 12
    y: -60
    z: 7
    execution: CONSOLE
    click: BOTH
    command: say CooldownOK
    created-by: TestBean
    created-at: 1793892693573
```

* Every change is saved **immediately**; saves are coalesced on one background thread so rapid
  changes never cause repeated disk writes.
* Writes are atomic (temporary file + atomic move), so a crash cannot leave a half-written file.
  `storage.backup-on-save: true` additionally keeps `blocks.yml.bak`.
* Entries whose world is not loaded are kept (never deleted) and are rebound to the real world
  UUID as soon as the world loads. Invalid entries are skipped with a warning
  (`storage.validate-on-load: true`).
* On shutdown all pending changes are flushed synchronously.

---

## 11. Behaviour details

**Click handling**

* Only `LEFT_CLICK_BLOCK` / `RIGHT_CLICK_BLOCK` on blocks that actually have a command are
  handled — everything else stays untouched vanilla behaviour.
* The configured click mode decides whether a click fires: a `right` block ignores left clicks,
  a `left` block ignores right clicks, `both` reacts to both.
* Right clicks fired twice (main hand / off hand) are de-duplicated
  (`interactions.prevent-offhand-duplicates`), and a repeated event in the same tick is ignored
  (`interactions.prevent-duplicate-interactions`).
* With `interactions.prevent-block-breaking: true` a configured block can never be broken by a
  player; a `BlockBreakEvent` fallback cancels the break even if the interaction itself was
  bypassed and informs the player (`general.block-protected`).
* With `interactions.allow-normal-interaction: false` the block's normal use (opening a chest,
  pressing a button…) is cancelled so only the command runs.
* `interactions.run-when-event-cancelled: true` makes the plugin react even when another plugin
  cancelled the interaction.

**Execution**

* `console` → `Bukkit.dispatchCommand(consoleSender, command)`.
* `player` → `player.performCommand(command)` (respects the player's own permissions).
* `execution.show-failed-messages: true` informs the player when the command could not run.
* `execution.log-commands: true` writes every execution to the server log.
* Cooldowns only start after a successful execution; the cooldown message, sound and duration are
  all configurable.

**Worlds**

* `worlds.mode` = `all` / `whitelist` / `blacklist` + `worlds.list` (case-insensitive).
* `worlds.run-in-filtered-worlds: true` lets configured blocks still fire in excluded worlds.

---

## 12. Multi-version compatibility

* Compiled against `paper-api:1.20.1-R0.1-SNAPSHOT` with `--release 17`; `api-version: 1.20`.
* No NMS, no `CraftBukkit`, no reflection into server internals. The only reflection used is a
  defensive lookup of `org.bukkit.Sound` constants so that enum-style sound names keep resolving
  on versions where `Sound` is no longer an enum.
* Messages are rendered through Adventure's legacy serializer with hex support, which is present
  in every Paper version from 1.16 upwards.
* Events used are long-stable Bukkit events (`PlayerInteractEvent`, `BlockBreakEvent`,
  `BlockDamageEvent`, `WorldLoadEvent`).

---

## 13. Project structure

```
TA_BlockTrigger/
├─ pom.xml
├─ README.md
├─ docs/CONFIGURATION.md
├─ TA_BlockTrigger-1.0.0.jar          (pre-built)
└─ src/main/
   ├─ java/com/mamadta/tablocktrigger/
   │  ├─ TABlockTrigger.java          main class, lifecycle, reload, tasks
   │  ├─ command/
   │  │  ├─ BtCommand.java           /bt executor + argument parser
   │  │  └─ BtTabCompleter.java      tab completion
   │  ├─ config/
   │  │  ├─ ConfigManager.java        config.yml (typed, validated, cached)
   │  │  ├─ MessageManager.java       messages.yml + colour formatting
   │  │  └─ SoundManager.java         configurable, version-safe sounds
   │  ├─ manager/
   │  │  ├─ BlockCommandManager.java  in-memory index + persistence triggers
   │  │  ├─ CooldownManager.java      cooldowns + duplicate guard
   │  │  └─ PlaceholderManager.java   {player} {uuid} {world} {x} {y} {z}
   │  ├─ execution/
   │  │  └─ CommandDispatcher.java    console/player execution pipeline
   │  ├─ listener/
   │  │  ├─ BlockInteractionListener.java  clicks + block protection
   │  │  └─ WorldListener.java             rebinding on world load
   │  ├─ storage/
   │  │  └─ BlockStorage.java         blocks.yml, atomic async writes
   │  ├─ model/
   │  │  ├─ BlockCommand.java  BlockKey.java
   │  │  ├─ ExecutionType.java ClickMode.java
   │  └─ util/
   │     └─ TextUtil.java             colour + hex rendering
   └─ resources/
      ├─ plugin.yml
      ├─ config.yml
      ├─ messages.yml
      └─ blocks.yml
```

---

## 14. Verification

The plugin was built and exercised on a real **Paper 1.20.1 (build 196)** server with a real
client connection. Verified end-to-end:

* plugin loads/enables/reloads/disables without errors or warnings;
* `/bt console … right` binds a command and a right click executes it **exactly once**
  (off-hand duplicate correctly ignored);
* placeholders resolve (`{player}`, `{world}`, `{x}` …);
* `left` mode executes on left click and ignores right clicks;
* `both` mode executes on both click types;
* `player` execution runs as the player, `console` execution runs as the server;
* left-clicked configured blocks cannot be broken and commands still fire;
* two different blocks keep independent commands;
* `/bt remove` removes only the targeted block and reports when nothing is configured;
* non-OP players may click configured blocks but are denied `/bt` management;
* cooldowns block spam (per player, per block, with and without separate click types);
* `interactions.left-click: false` and the world whitelist take effect after `/bt reload`;
* `/bt reload` keeps all configured blocks and re-applies settings;
* sounds are delivered as native sound keys (no custom/unknown sound packets).

---

## 15. Troubleshooting

| Symptom | Cause / fix |
|---|---|
| `/bt` says you have no permission | You are not OP while `permissions.op-only: true`. Use `/op <name>` or grant `tablocktrigger.admin` and set `permissions.use-permission-node: true`. |
| "You are not looking at a block within N blocks" | Look directly at the block face; increase `settings.max-selection-distance` if needed. |
| Clicking does nothing | Check the block's click mode, `interactions.right-click` / `left-click` / `both`, the world filter and `settings.enabled`. Enable `settings.debug: true` for detailed console output. |
| No sounds | Check `sounds.enabled` and the slot's `enabled`; watch the console for "Unknown sound" warnings. |
| Block can be broken | `interactions.prevent-block-breaking` must be `true`. |
| Changes to `config.yml` do nothing | Run `/bt reload` or restart. |

---

*TA_BlockTrigger — built for Paper 1.20.1+, by MamaD_TA.*
